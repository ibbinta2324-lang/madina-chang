// Service worker minimal : ne met rien en cache de façon agressive
// (les annonces viennent de Supabase et doivent toujours être à jour),
// il sert surtout à rendre le site "installable" comme une application.

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
