import { useEffect } from "react";
import "../styles/globals.css";
import Navbar from "../components/Navbar";

export default function App({ Component, pageProps }) {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // Si l'enregistrement échoue, le site continue de fonctionner
        // normalement, simplement sans installation en PWA.
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navbar />
      <Component {...pageProps} />
    </div>
  );
}
